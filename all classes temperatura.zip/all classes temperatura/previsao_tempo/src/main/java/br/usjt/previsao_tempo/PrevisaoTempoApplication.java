package br.usjt.previsao_tempo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrevisaoTempoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrevisaoTempoApplication.class, args);
	}

}
